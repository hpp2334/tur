use std::cell::Cell;
use std::cell::RefCell;
use std::fmt;
use std::rc::Rc;

use crate::core::layout::Constraints;
use boa_engine::context::time::Clock;
use parley::LayoutContext as ParleyLayoutContext;

use crate::core::app::{AppEvent, AppEventQueue};
use crate::core::async_::CompletionHandle;
use crate::core::capability::Capabilities;
use crate::core::edgy::mutation::PendingMutationInvocationQueue;
use crate::core::elements::NodeTree;
use crate::core::focus::FocusManager;
use crate::core::fonts::FontManager;
use crate::core::frame_env::FrameEnv;
use crate::core::image_resource::ImageManager;
use crate::core::platform::{PlatformEvent, PlatformEventQueue, PointerDeviceKind, PointerInput};
use crate::core::render::{RecordingCanvas, RenderCommand};
use crate::core::scheduler::WorkerContext;
use crate::core::screen::Screen;
use crate::core::shell::ShellEvent;
use crate::core::subsystem::{Subsystem, SubsystemFlushContext};

pub struct TurAppContext {
    /// The instance-owned tree (shared with [`TurInstanceContext`]) —
    /// created at build born-bound to the instance store. Layout / paint /
    /// event dispatch operate on it directly; before the first `mount` it is
    /// simply rootless (empty layout, empty paint — the historical
    /// pre-mount behavior).
    pub(crate) element_tree: NodeTree,
    pub(crate) mutation_queue: Rc<RefCell<PendingMutationInvocationQueue>>,
    pub(crate) focus_manager: Rc<RefCell<FocusManager>>,
    /// Worker-side image state (natural-size map + next-id counter — the
    /// pixel `Blob` lives on the host thread, shipped via `HostMsg::UploadImage`).
    pub(crate) image_manager: Rc<RefCell<ImageManager>>,
    pub(crate) font_manager: FontManager,
    pub(crate) text_layout_cx: ParleyLayoutContext<[u8; 4]>,
    pub(crate) screen: Screen,
    pub(crate) platform_event_queue: PlatformEventQueue,
    pub(crate) app_event_queue: AppEventQueue,
    /// Worker-thread scheduler — cloned from `TurAppInternal::worker_ctx`.
    /// Surfaced to subsystems via [`SubsystemFlushContext`] so they can
    /// spawn Rust futures (clipboard writes, etc.) at dispatch time.
    pub(crate) worker_ctx: WorkerContext,
    /// Cheap-cloned completion handle — cloned from
    /// `TurAppInternal::completion_handle`. Surfaced to subsystems so
    /// spawned futures can push promise-settle closures for `flush()` to
    /// drain under `&mut Context`.
    pub(crate) completion_handle: CompletionHandle,
    /// Capability registry view, shared with `TurInstanceContext.capabilities`.
    /// Surfaced to subsystems via [`SubsystemFlushContext::capabilities`] so
    /// they can look up backends (`Clipboard`, `Http`, etc.) at dispatch
    /// time.
    pub(crate) capabilities: Capabilities,
    /// FrameEnv layer: clock, pointer position, and cursor output (pushed to the
    /// embedder via a callback installed by a plugin). Owns the time source
    /// shared with the boa `Context`. See [`FrameEnv`].
    pub(crate) frame_env: FrameEnv,
}

impl fmt::Debug for TurAppContext {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("TurAppContext")
            .field("logical_size", &self.screen.logical_size)
            .finish_non_exhaustive()
    }
}

impl TurAppContext {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        element_tree: NodeTree,
        mutation_queue: Rc<RefCell<PendingMutationInvocationQueue>>,
        focus_manager: Rc<RefCell<FocusManager>>,
        image_manager: Rc<RefCell<ImageManager>>,
        font_context: crate::core::fonts::FontContext,
        font_loader: std::sync::Arc<dyn crate::core::fonts::FontLoader>,
        worker_ctx: WorkerContext,
        completion_handle: CompletionHandle,
        capabilities: Capabilities,
        clock: Rc<dyn Clock>,
    ) -> Self {
        let font_manager = FontManager::from_context(font_context, font_loader);
        Self {
            element_tree: element_tree.clone(),
            mutation_queue,
            focus_manager,
            image_manager,
            font_manager,
            text_layout_cx: ParleyLayoutContext::new(),
            screen: Screen::new(),
            platform_event_queue: PlatformEventQueue::new(),
            app_event_queue: AppEventQueue::new(),
            worker_ctx,
            completion_handle,
            capabilities,
            frame_env: FrameEnv::new(clock),
        }
    }

    /// Dispatch a platform (input) event to every registered subsystem via
    /// [`Subsystem::handle_platform_event`]. Mouse `PointerMove`s also
    /// update the frame_env's tracked pointer position and request a paint, since
    /// the cursor is resolved during paint (not in a subsystem).
    pub fn dispatch_platform_event(
        &mut self,
        boa: &mut boa_engine::Context,
        event: &PlatformEvent,
        need_paint: &Cell<bool>,
        subsystems: &mut [Box<dyn Subsystem>],
        signals: &crate::core::subsystem::FlushSignals<'_>,
    ) {
        if let PlatformEvent::Shell(ShellEvent::Pointer(PointerInput::PointerMove {
            position,
            device: PointerDeviceKind::Mouse,
            time_ms: _,
        })) = event
        {
            self.frame_env.set_pointer_position(Some(*position));
            need_paint.set(true);
        }

        let mut cx = SubsystemFlushContext {
            boa,
            element_tree: self.element_tree.clone(),
            focus_manager: self.focus_manager.clone(),
            mutation_queue: self.mutation_queue.clone(),
            platform_event_queue: &mut self.platform_event_queue,
            app_event_queue: &mut self.app_event_queue,
            screen: &mut self.screen,
            need_paint,
            worker_ctx: &self.worker_ctx,
            completion_handle: &self.completion_handle,
            capabilities: &self.capabilities,
            frame_id: signals.frame_id,
            sub_dirty: signals.sub_dirty,
            sub_request_frame: signals.sub_request_frame,
        };
        for sub in subsystems {
            sub.handle_platform_event(&mut cx, event);
        }
    }

    /// Dispatch an engine-internal event to every registered subsystem via
    /// [`Subsystem::handle_app_event`].
    pub fn dispatch_app_event(
        &mut self,
        boa: &mut boa_engine::Context,
        event: &AppEvent,
        need_paint: &Cell<bool>,
        subsystems: &mut [Box<dyn Subsystem>],
        signals: &crate::core::subsystem::FlushSignals<'_>,
    ) {
        let mut cx = SubsystemFlushContext {
            boa,
            element_tree: self.element_tree.clone(),
            focus_manager: self.focus_manager.clone(),
            mutation_queue: self.mutation_queue.clone(),
            platform_event_queue: &mut self.platform_event_queue,
            app_event_queue: &mut self.app_event_queue,
            screen: &mut self.screen,
            need_paint,
            worker_ctx: &self.worker_ctx,
            completion_handle: &self.completion_handle,
            capabilities: &self.capabilities,
            frame_id: signals.frame_id,
            sub_dirty: signals.sub_dirty,
            sub_request_frame: signals.sub_request_frame,
        };
        for sub in subsystems {
            sub.handle_app_event(&mut cx, event);
        }
    }

    pub fn layout(&mut self, dirty: Rc<Cell<bool>>, boa: &mut boa_engine::Context) {
        let (width, height) = self.screen.logical_size;
        let constraints = Constraints {
            min_width: width,
            max_width: width,
            min_height: height,
            max_height: height,
        };

        let image_manager = self.image_manager.borrow();
        let node_tree = self.element_tree.clone();
        let mut tree = self.element_tree.borrow_mut();
        tree.compute_layout(
            &constraints,
            &mut self.font_manager,
            &mut self.text_layout_cx,
            &image_manager,
            node_tree,
            self.mutation_queue.clone(),
            dirty,
            boa,
        );
    }

    /// Walk the element tree with a [`RecordingCanvas`] to capture per-node
    /// paint ops + boundaries, post-process the recording into
    /// `Vec<RenderCommand>` (paint commands in playback order), and return
    /// the batch.
    ///
    /// The caller is responsible for shipping the batch to whichever
    /// thread/realm owns the actual renderer. The worker stores it in
    /// `TurAppInternal::pending_render_batch` for `HostBackend::worker_loop`
    /// to drain and ship via `HostMsg::RenderCommands`.
    pub fn build_render_batch(&mut self) -> Vec<RenderCommand> {
        let focused_node_id = self.focus_manager.borrow().focused();

        // Record the paint pass. Seed the recording canvas with the logical
        // viewport as the bottom-of-stack clip so off-screen subtrees are
        // culled during the walk (content outside the screen is invisible
        // anyway). Explicit element clips (ScrollView, overflow-Flex, …)
        // push further inner clips intersected with this viewport.
        let tree = self.element_tree.borrow();
        let (vp_w, vp_h) = self.screen.logical_size;
        let mut recording = RecordingCanvas::new_with_viewport(vello_common::kurbo::Rect::new(
            0.0, 0.0, vp_w, vp_h,
        ));
        {
            let frame_env = self.frame_env.paint_env();
            tree.paint(
                &mut recording,
                focused_node_id,
                &self.image_manager.borrow(),
                frame_env,
            );
        }
        drop(tree);

        // Collect the paint commands into one batch.
        let batch = recording.into_render_commands();

        // Flush cursor claims accumulated during the record pass.
        self.frame_env.apply_cursor_changes();

        batch
    }
}
