pub trait ElementOnFocus: 'static {}
