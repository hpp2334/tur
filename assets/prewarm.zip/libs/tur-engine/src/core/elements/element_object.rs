use std::fmt;

use crate::core::layout::{ComputedLayout, Constraints};
use boa_engine::Context;

use crate::core::element::{ElementNodeId, NodeId};
use crate::core::elements::AnyElement;
use crate::core::js_runtime::{BoaOpaque, TurNodeHandle};

pub struct ElementObject {
    pub id: ElementNodeId,
    pub element: Option<AnyElement>,
    pub children: Vec<NodeId>,
    pub parent: Option<NodeId>,
    pub computed_layout: ComputedLayout,
    pub(crate) query_key: Option<Vec<String>>,
    #[allow(dead_code)]
    handle: BoaOpaque<TurNodeHandle>,
    pub(crate) dirty_layout: bool,
    pub(crate) last_constraints: Option<Constraints>,
}

impl fmt::Debug for ElementObject {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("ElementObject")
            .field("id", &self.id)
            .field("kind", &self.element.as_ref().map(|e| e.kind()))
            .field("children", &self.children)
            .field("parent", &self.parent)
            .finish()
    }
}

impl ElementObject {
    pub fn new(id: ElementNodeId, element: AnyElement, context: &mut Context) -> Self {
        ElementObject {
            handle: BoaOpaque::new(TurNodeHandle { id }, context),
            id,
            element: Some(element),
            children: Vec::new(),
            parent: None,
            computed_layout: ComputedLayout::ZERO,
            query_key: None,
            dirty_layout: true,
            last_constraints: None,
        }
    }
}
